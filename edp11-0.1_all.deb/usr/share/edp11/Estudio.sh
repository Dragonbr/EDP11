#!/bin/bash

cd /usr/share/edp11/

python mainmenu.py
